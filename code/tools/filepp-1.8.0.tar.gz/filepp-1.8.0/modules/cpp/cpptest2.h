#define SOMETHING_FISHY 2
#ifdef TEST
#endif
#ifndef TEST1
#endif
SOMETHING_FISHY
