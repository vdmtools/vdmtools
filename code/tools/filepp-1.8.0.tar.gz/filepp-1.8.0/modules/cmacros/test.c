BASE_FILE	__BASE_FILE__
DATE		__DATE__
FILE		__FILE__
TIME		__TIME__
VERSION		__VERSION__
#include "testinc.h"
